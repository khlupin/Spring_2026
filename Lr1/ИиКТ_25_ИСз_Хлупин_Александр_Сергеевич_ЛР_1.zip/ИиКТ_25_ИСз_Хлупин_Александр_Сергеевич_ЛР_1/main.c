#include <stdio.h>
#include <string.h>

int main(void) {
  char fio[256];

  char* surname;
  char* name;
  char* patronymic;

  printf("Введите ФИО: ");
  scanf("%255[^\n]", fio);

  surname = strtok(fio, " ");
  name = strtok(NULL, " ");
  patronymic = strtok(NULL, " ");

  printf("Фамилия: %s\n", surname);
  printf("Имя: %s\n", name);
  printf("Отчество: %s\n", patronymic);

  printf("Инициалы: %.2s.%.2s.\n", name, patronymic);

  printf("Полное ФИО: %s %s %s\n", surname, name, patronymic);

  return 0;
}